//Ξ�Ο‰Ο†ΞΏΞΊΟ�Ο„ΟƒΞΉΞΏΟ‚ Ξ—Ξ»Ξ―Ξ±Ο‚ 9380 6944316621 ikofokots@ece.auth.gr
//Ξ£ΞΊΞ±Ο€Ξ­Ο„Ξ·Ο‚ Ξ§Ο�Ξ®ΟƒΟ„ΞΏΟ‚ 9378 6933251534 skapetis@ece.auth.gr

// IF THE COMMENTS CANNOT BE SEEN CHANGE THE ENCODING TO UTF-8
package src;

/* Snake Class.
 * Ξ ΞµΟ�ΞΉΞ­Ο‡ΞΏΞ½Ο„Ξ±ΞΉ ΞΏΞΉ ΞΌΞµΟ„Ξ±Ξ²Ξ»Ξ·Ο„Ξ­Ο‚ snakeId, headId, tailId, Ο�Ξ»ΞµΟ‚ Ο„Ο�Ο€ΞΏΟ… int
 * ΞΏΞΉ ΞΏΟ€ΞΏΞ―ΞµΟ‚ Ξ±Ξ½Ο„ΞΉΟƒΟ„ΞΏΞΉΟ‡ΞΏΟ�Ξ½ ΟƒΟ„ΞΏ id Ο„ΞΏΟ… Ο†ΞΉΞ΄ΞΉΞΏΟ�,
 * Ο„ΞΏ id Ο„ΞΏΟ… Ο€Ξ»Ξ±ΞΊΞΉΞ΄Ξ―ΞΏΟ… Ο„ΞΏΟ… Ο„Ξ±ΞΌΟ€Ξ»Ο� Ο�Ο€ΞΏΟ… Ξ²Ο�Ξ―ΟƒΞΊΞµΟ„Ξ±ΞΉ Ο„ΞΏ ΞΊΞµΟ†Ξ¬Ξ»ΞΉ Ο„ΞΏΟ… Ο†ΞΉΞ΄ΞΉΞΏΟ� ΞΊΞ±ΞΉ
 * Ο„ΞΏ id Ο„ΞΏΟ… Ο€Ξ»Ξ±ΞΊΞΉΞ΄Ξ―ΞΏΟ… Ο„ΞΏΟ… Ο„Ξ±ΞΌΟ€Ξ»Ο� Ο�Ο€ΞΏΟ… Ξ²Ο�Ξ―ΟƒΞΊΞµΟ„Ξ±ΞΉ Ξ· ΞΏΟ…Ο�Ξ¬ Ο„ΞΏΟ… Ο†ΞΉΞ΄ΞΉΞΏΟ� Ξ±Ξ½Ο„Ξ―ΟƒΟ„ΞΏΞΉΟ‡Ξ±.
 * Ξ ΞµΟ�ΞΉΞ­Ο‡ΞΏΞ½Ο„Ξ±ΞΉ 3 constructors, Ξ­Ξ½Ξ±Ο‚ Ο‡Ο‰Ο�Ξ―Ο‚ Ο�Ο�ΞΉΟƒΞΌΞ±Ο„Ξ±, Ξ­Ξ½Ξ±Ο‚ ΞΌΞµ Ο�Ο�ΞΉΟƒΞΌΞ±Ο„Ξ± ΞΊΞ±ΞΉ ΞΌΞµ
 * Ξ­Ξ½Ξ±Ο‚ ΞΌΞµ Ο�Ο�ΞΉΟƒΞΌΞ± Ξ±Ξ½Ο„ΞΉΞΊΞµΞ―ΞΌΞµΞ½ΞΏ.
 * Ξ ΞµΟ�ΞΉΞ­Ο‡ΞΏΞ½Ο„Ξ±ΞΉ 3 getters ΞΊΞ±ΞΉ 3 setters, Ξ±Ο€Ο� Ξ­Ξ½Ξ± Ξ¶ΞµΟ�Ξ³ΞΏΟ‚ Ξ³ΞΉΞ± ΞΊΞ¬ΞΈΞµ ΞΌΞµΟ„Ξ±Ξ²Ξ»Ξ·Ο„Ξ® Ο„Ξ·Ο‚
 * ΞΊΞ»Ξ¬ΟƒΞ·Ο‚ Ξ±Ο…Ο„Ξ®Ο‚.
 */ 
public class Snake {
	private int snakeId;
	private int headId;
	private int tailId;

	//Ξ�ΞµΞ½Ο�Ο‚ constructor
	public Snake()
	{
		snakeId = 0;
		headId = 0;
		tailId = 0;
	}

	// Constructor ΞΌΞµ ΞΏΟ�Ξ―ΟƒΞΌΞ±Ο„Ξ±
	public Snake(int snakeId, int headId, int tailId)
	{
		this.snakeId = snakeId;
		this.headId = headId;
		this.tailId = tailId;
	}

	//Constructor ΞΌΞµ Ο�Ο�ΞΉΟƒΞΌΞ± Ξ­Ξ½Ξ± Ξ±Ξ½Ο„ΞΉΞΊΞµΞ―ΞΌΞµΞ½ΞΏ
	public Snake(Snake S)
	{
		this.snakeId = S.snakeId;
		this.headId = S.headId;
		this.tailId = S.tailId;
	}

	//Getters
	public int getSnakeId()
	{
		return snakeId;
	}

	public int getHeadId()
	{
		return headId;
	}

	public int getTailId()
	{
		return tailId;
	}

	//Setters
	public void setSnakeId(int a)
	{
		snakeId = a;
	}

	public void setHeadId(int a)
	{
		headId = a;
	}

	public void setTailId(int a)
	{
		tailId = a;
	}


}
