//Ξ�Ο‰Ο†ΞΏΞΊΟ�Ο„ΟƒΞΉΞΏΟ‚ Ξ—Ξ»Ξ―Ξ±Ο‚ 9380 6944316621 ikofokots@ece.auth.gr
//Ξ£ΞΊΞ±Ο€Ξ­Ο„Ξ·Ο‚ Ξ§Ο�Ξ®ΟƒΟ„ΞΏΟ‚ 9378 6933251534 skapetis@ece.auth.gr

// IF THE COMMENTS CANNOT BE SEEN CHANGE THE ENCODING TO UTF-8
package src;

/* Ladder Class
 * Ξ ΞµΟ�ΞΉΞ­Ο‡ΞΏΞ½Ο„Ξ±ΞΉ ΞΏΞΉ ΞΌΞµΟ„Ξ±Ξ²Ξ»Ξ·Ο„Ξ­Ο‚ ladderId, upStepId, downStepId, broken. ΞΏ
 * Ξ�ΞΉ 3 Ο€Ο�Ο�Ο„ΞµΟ‚ ΞµΞ―Ξ½Ξ±ΞΉ Ο„Ο�Ο€ΞΏΟ… int ΞΊΞ±ΞΉ Ξ· Ο„ΞµΞ»ΞµΟ…Ο„Ξ±Ξ―Ξ± boolean ΞΊΞ±ΞΉ
 * Ξ±Ξ½Ο„ΞΉΟƒΟ„ΞΏΞΉΟ‡ΞΏΟ�Ξ½ ΟƒΟ„ΞΏ id Ο„Ξ·Ο‚ ΟƒΞΊΞ¬Ξ»Ξ±Ο‚,
 * Ο„ΞΏ id Ο„ΞΏΟ… Ο€Ξ»Ξ±ΞΊΞΉΞ΄Ξ―ΞΏΟ… Ο„ΞΏΟ… Ο„Ξ±ΞΌΟ€Ξ»Ο� Ο�Ο€ΞΏΟ… Ξ²Ο�Ξ―ΟƒΞΊΞµΟ„Ξ±ΞΉ Ξ· Ξ²Ξ¬ΟƒΞ· Ο„Ξ·Ο‚ ΟƒΞΊΞ¬Ξ»Ξ±Ο‚ ΞΊΞ±ΞΉ
 * Ο„ΞΏ id Ο„ΞΏΟ… Ο€Ξ»Ξ±ΞΊΞΉΞ΄Ξ―ΞΏΟ… Ο„ΞΏΟ… Ο„Ξ±ΞΌΟ€Ξ»Ο� Ο�Ο€ΞΏΟ… Ξ²Ο�Ξ―ΟƒΞΊΞµΟ„Ξ±ΞΉ Ξ· ΞΊΞΏΟ�Ο…Ο†Ξ® Ο„Ξ·Ο‚ ΟƒΞΊΞ¬Ξ»Ξ±Ο‚ Ξ±Ξ½Ο„Ξ―ΟƒΟ„ΞΏΞΉΟ‡Ξ±,
 * ΞµΞ½Ο� Ο„ΞΏ broken Ξ΄ΞµΞ―Ο‡Ξ½ΞµΞΉ Ξ±Ξ½ Ξ· ΟƒΞΊΞ¬Ξ»Ξ± ΞµΞ―Ξ½Ξ±ΞΉ ΟƒΟ€Ξ±ΟƒΞΌΞ­Ξ½Ξ· Ξ® Ο�Ο‡ΞΉ.
 * Ξ ΞµΟ�ΞΉΞ­Ο‡ΞΏΞ½Ο„Ξ±ΞΉ 3 constructors, Ξ­Ξ½Ξ±Ο‚ Ο‡Ο‰Ο�Ξ―Ο‚ Ο�Ο�ΞΉΟƒΞΌΞ±Ο„Ξ±, Ξ­Ξ½Ξ±Ο‚ ΞΌΞµ Ο�Ο�ΞΉΟƒΞΌΞ±Ο„Ξ± ΞΊΞ±ΞΉ Ξ­Ξ½Ξ±Ο‚
 * ΞΌΞµ Ο�Ο�ΞΉΟƒΞΌΞ± Ξ±Ξ½Ο„ΞΉΞΊΞµΞ―ΞΌΞµΞ½ΞΏ.
 * Ξ ΞµΟ�ΞΉΞ­Ο‡ΞΏΞ½Ο„Ξ±ΞΉ 4 getters ΞΊΞ±ΞΉ 4 setters, Ξ±Ο€Ο� Ξ­Ξ½Ξ± Ξ¶ΞµΟ�Ξ³ΞΏΟ‚ Ξ³ΞΉΞ± ΞΊΞ¬ΞΈΞµ ΞΌΞµΟ„Ξ±Ξ²Ξ»Ξ·Ο„Ξ®
 * Ο„Ξ·Ο‚ ΞΊΞ»Ξ¬ΟƒΞ·Ο‚ Ξ±Ο…Ο„Ξ®Ο‚.
 */ 
public class Ladder {
	private int ladderId;
	private int upStepId;
	private int downStepId;
	private boolean broken;

	//Ξ�ΞµΞ½Ο�Ο‚ constructor
	public Ladder()
	{
		ladderId = 0;
		upStepId = 0;
		downStepId = 0;
		broken = false;
	}

	// Constructor ΞΌΞµ ΞΏΟ�Ξ―ΟƒΞΌΞ±Ο„Ξ±
	public Ladder(int ladderId, int upStepId, int downStepId, boolean broken)
	{
		this.ladderId = ladderId;
		this.upStepId = upStepId;
		this.downStepId = downStepId;
		this.broken = broken;
	}

	//Constructor ΞΌΞµ Ο�Ο�ΞΉΟƒΞΌΞ± Ξ­Ξ½Ξ± Ξ±Ο„ΞΉΞΊΞµΞ―ΞΌΞµΞ½ΞΏ
	public Ladder(Ladder L)
	{
		this.ladderId = L.ladderId;
		this.upStepId = L.upStepId;
		this.downStepId = L.downStepId;
		this.broken = L.broken;
	}

	//Getters
	public int getLadderId()
	{
		return ladderId;
	}

	public int getUpStepId()
	{
		return upStepId;
	}

	public int getDownStepId()
	{
		return downStepId;
	}

	public boolean getBroken()
	{
		return broken;
	}

	//Setters
	public void setLadderId(int a)
	{
		ladderId = a;
	}

	public void setUpStepID(int a)
	{
		upStepId = a;
	}

	public void setDownStepId(int a)
	{
		downStepId = a;
	}

	public void setBroken(boolean a)
	{
		broken = a;
	}
}
