package src;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ArrayList<Object> players = new ArrayList<Object>();
		
		for(int i=0; i<10; i++) {
			players.add(new Player(i+1, Integer.toString(i), 0, null));
		}
		
		Map<Integer, Integer> dice = new HashMap<Integer, Integer>();
		for(int i=0; i<players.size(); i++)
		{
			dice.put(((Player)players.get(i)).getPlayerId(),(int)(Math.random()*6+1));
		}
		Map<Integer, Integer> diceSorted = new LinkedHashMap<Integer, Integer>();
		int size = dice.size();
		for(int i=1; i<=dice.size(); i++) {
			System.out.println(i + " " + dice.get(i));
		}
		for(int i=1; i<=size; i++) {
			AbstractMap.SimpleEntry<Integer, Integer> min = new SimpleEntry<Integer, Integer>(dice.size(), 7);
			for(int j=1; j<=size; j++) {
				System.out.println(j);
				if(dice.get(j)==null)
					continue;
				if(dice.get(j) < min.getValue()) {
					min = new SimpleEntry<Integer, Integer>(j, dice.get(j));
				}
			}
			dice.remove(min.getKey());
			diceSorted.put(min.getKey(), min.getValue());
			for(int k=1; k<=size; k++) {
				System.out.println(k + " " + dice.get(k));
			}
		}
		
		System.out.println(diceSorted.keySet() + " " + diceSorted.values());
//		for(int i=1; i<=diceSorted.size(); i++) {
//			System.out.println(i + " "+diceSorted.get(i)+" $$");
//			diceSorted.re
//		}

	}

}
