// IF THE COMMENTS CANNOT BE SEEN CHANGE THE ENCODING TO UTF-8
package src;

import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.AbstractMap;
import java.util.AbstractMap.SimpleEntry;
import java.util.Iterator;

public class Game {
	private int round;

	//  constructor
	public Game() {
		round = 0;
	}

	// Constructor 
	public Game(int r) {
		round = r;
	}

	// Setter
	public void setRound(int round) {
		if(round > 0)
			this.round = round;
		else
			System.out.println("Setter Error: The game round cannot be less than 1. No alterations have been made.");
	}

	//Getter
	public int getRound() {
		return round;
	}

	public Map<Integer, Integer> setTurns(ArrayList<Object> players)
	{
		Map<Integer, Integer> dice = new HashMap<Integer, Integer>();
		for(int i=0; i<players.size(); i++)
		{
			dice.put(((Player)players.get(i)).getPlayerId(),(int)(Math.random()*6+1));
		}
		Map<Integer, Integer> diceSorted = new LinkedHashMap<Integer, Integer>();
		int size = dice.size();

		for(int i=1; i<=size; i++) {
			AbstractMap.SimpleEntry<Integer, Integer> min = new SimpleEntry<Integer, Integer>(dice.size(), 7);
			for(int j=1; j<=size; j++) {
				if(dice.get(j)==null)
					continue;
				if(dice.get(j) < min.getValue()) {
					min = new SimpleEntry<Integer, Integer>(j, dice.get(j));
				}
			}
			dice.remove(min.getKey());
			diceSorted.put(min.getKey(), min.getValue());
		}
		
		
		return diceSorted;
	}
	
	
	public static void main(String[] args) {
		Game game = new Game(0);
		Board board = new Board(10, 20, 3, 3, 6);
		ArrayList<Object> players = new ArrayList<Object>();
		players.add(new Player(1, "Christos", 0, board));
		players.add(new HeuristicPlayer(2, "Ilias", 0, board));
		Map<Integer, Integer> dice = game.setTurns(players);
		
		boolean finished = false;
		int [] array = new int[5];
		int id = 0;
		
		do {
			for (Map.Entry<Integer, Integer> entry : dice.entrySet()) {
				if(players.get(entry.getKey()) instanceof HeuristicPlayer) {
					((Player)players.get(entry.getKey())).move(array[0], (int) (Math.random()*6+1));
				}
				else {
					((HeuristicPlayer) players.get(entry.getKey())).getNextMove(id);
				}
			} 
		} while (!finished);

	}

}
